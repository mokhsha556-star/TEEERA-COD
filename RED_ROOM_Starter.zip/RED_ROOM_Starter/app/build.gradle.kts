plugins {
    id("com.android.application")
}

android {
    namespace = "com.redroom.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.redroom.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
