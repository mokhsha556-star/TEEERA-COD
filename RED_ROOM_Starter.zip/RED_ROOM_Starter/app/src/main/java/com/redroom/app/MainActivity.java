package com.redroom.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(8, 8, 10);
    private static final int GOLD = Color.rgb(212, 175, 55);
    private static final int MUTED = Color.rgb(185, 180, 160);
    private static final String PIN_SHA256 = "6f9a8cfc5b038afd309262656936194ba27e10ef934dde14c5f96ed990f71fc6";
    private LinearLayout root;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        showLogin();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(12, 12, 12, 12);
        return t;
    }

    private LinearLayout column() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(22, 24, 22, 24);
        box.setBackgroundColor(BG);
        return box;
    }

    private Button goldButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.BLACK);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GOLD));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 7, 0, 7);
        b.setLayoutParams(p);
        return b;
    }

    private String sha256(String input) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] bytes = digest.digest(input.getBytes(StandardCharsets.UTF_8));
        StringBuilder out = new StringBuilder();
        for (byte b : bytes) out.append(String.format("%02x", b & 0xff));
        return out.toString();
    }

    private void showLogin() {
        root = column();
        root.setGravity(Gravity.CENTER);
        TextView logo = text("RED ROOM", 32, GOLD, true);
        root.addView(logo);
        root.addView(text("PURE GOLD • SECURE ACCESS", 12, MUTED, true));
        root.addView(text("أدخل رمز الدخول للمتابعة", 17, Color.WHITE, false));
        EditText pin = new EditText(this);
        pin.setSingleLine(true);
        pin.setHint("رمز الدخول");
        pin.setHintTextColor(MUTED);
        pin.setTextColor(Color.WHITE);
        pin.setGravity(Gravity.CENTER);
        pin.setInputType( android.text.InputType.TYPE_CLASS_NUMBER
            | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pin.setPadding(18, 14, 18, 14);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        ep.setMargins(0, 18, 0, 12);
        root.addView(pin, ep);
        Button enter = goldButton("دخول");
        root.addView(enter);
        enter.setOnClickListener(v -> {
            try {
                if (MessageDigest.isEqual(sha256(pin.getText().toString()).getBytes(StandardCharsets.UTF_8),
                                         PIN_SHA256.getBytes(StandardCharsets.UTF_8))) {
                    showDashboard();
                } else {
                    pin.setText("");
                    Toast.makeText(this, "رمز الدخول غير صحيح", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "تعذر التحقق من الرمز", Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(text("المطوّر: محمد محمود • إصدار 0.1.0", 12, MUTED, false));
        setContentView(root);
    }

    private void showDashboard() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = column();
        page.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        page.addView(text("RED ROOM", 30, GOLD, true));
        page.addView(text("لوحة التحكم", 18, Color.WHITE, true));
        String[][] sections = {
            {"📱 صيانة وفورمات الهواتف", "تشخيص الاتصال وإرشادات الصيانة؛ لا يوجد مسح تلقائي."},
            {"🛠️ السوفت وير", "معلومات النظام وخطوات الإصلاح الرسمية."},
            {"💾 الذاكرة والتخزين", "عرض إرشادات التخزين والنسخ الاحتياطي."},
            {"🔐 أدوات كلمات المرور", "توليد كلمات مرور وفحص قوتها؛ لا كسر أو تجاوز حماية."},
            {"⌨️ الطرفية الآمنة", "واجهة تعليمية لأوامر آمنة."},
            {"🤖 المساعد الذكي", "واجهة أولية؛ يتطلب الاتصال بخدمة ذكاء اصطناعي لتعمل فعليًا."},
            {"📝 الملاحظات المحمية", "واجهة أولية؛ يلزم تنفيذ تخزين محلي آمن."},
            {"👤 الملف الشخصي", "المطوّر: محمد محمود • الإصدار 0.1.0"}
        };
        for (String[] section : sections) {
            TextView item = text(section[0] + "\n" + section[1], 15, GOLD, true);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setBackgroundColor(Color.rgb(22, 20, 15));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            p.setMargins(0, 6, 0, 6);
            page.addView(item, p);
        }
        Button lock = goldButton("قفل التطبيق");
        lock.setOnClickListener(v -> showLogin());
        page.addView(lock);
        scroll.addView(page);
        setContentView(scroll);
    }
}
