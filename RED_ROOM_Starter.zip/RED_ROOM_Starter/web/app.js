// Prototype only: client-side checks can be inspected and bypassed; don't use for sensitive secrets.
const expectedHash = "6f9a8cfc5b038afd309262656936194ba27e10ef934dde14c5f96ed990f71fc6";
const login = document.getElementById("login");
const dashboard = document.getElementById("dashboard");
const form = document.getElementById("loginForm");
const pin = document.getElementById("pin");
const error = document.getElementById("error");
async function sha256(value) {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, "0")).join("");
}
form.addEventListener("submit", async event => {
  event.preventDefault();
  if (await sha256(pin.value) === expectedHash) {
    login.classList.add("hidden");
    dashboard.classList.remove("hidden");
    error.textContent = "";
    pin.value = "";
  } else {
    error.textContent = "رمز الدخول غير صحيح";
    pin.value = "";
  }
});
document.getElementById("lock").addEventListener("click", () => {
  dashboard.classList.add("hidden");
  login.classList.remove("hidden");
  pin.value = "";
});
document.getElementById("year").textContent = new Date().getFullYear();
